<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title>newproduction</title>
  </head>
  <body>
    <nav class="navbar navbar-default">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Home</a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
          <ul class="nav navbar-nav">
            <li><a href="#">About</a></li>
            <li><a href="#">Shooting Locations</a></li>
            <li><a href="#">Approved Films</a></li>
            <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="#">Stakeholders
              <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="#">Police Department</a></li>
                <li><a href="#">Municipal Department</a></li>
                <li><a href="#">Archaelogical Department</a></li>
              </ul>
            </li>
            <li><a href="#">DFSP Approval</a></li>
            <li><a href="#">Contact</a></li>
          </ul>
        </div>
      </div>
    </nav>
    <div class="box">
      <form class="registerform" action="registersendtodatabase.php" method="post" onsubmit="return verhoeffvalidate()">
        <div class="form-group">
          <label for="pname">Production Name:</label>
          <input type="text" class="form-control" id="pname" name="pname" required="10" minlegth="8" maxlength="20" placeholder="eg. Marvel Studios">
        </div>
        <div class="form-group">
          <label for="oname">Production Owner:</label>
          <input type="text" class="form-control" id="prname" name="oname" required="10" minlegth="8" maxlength="20" placeholder="eg. Kevin Feige">
        </div>
        <div class="form-group">
          <label for="email">Email id:</label>
          <input type="email" class="form-control" id="email" name="email" placeholder="Please enter valid email id">
        </div>
        <div class="form-group">
          <label for="mobile">Mobile Number:</label>
          <input type="text" class="form-control" id="mobile" name="mobile" required="10" minlength="10" maxlength="10"  placeholder="Enter 10 digit mobile number" onkeypress="return isNumberKey(event)">
        </div>
        <div class="form-group">
          <label for="address">Address:</label>
          <textarea class="form-control" rows="4" id="address" name="address" placeholder="Address of production house" required="15" minlength="15" maxlength="100"></textarea>
        </div>
        <div class="form-group">
          <label for="aadhar">Aadhar number:</label>
          <input type="text" class="form-control" id="aadhar" name="aadhar" maxlength="12" onkeypress="return isNumberKey(event)" placeholder="Enter 12-digit Aadhar Number">
          <div style="background-color:#ff8a8a; color:white; height:20px;margin-top:10px; display:none;" id="check_aadhar">
              <span style="color:white; font-weight:bold; float:right; font-size:10px;">
              </span>
                Invalid Aadhar
            </div>
        </div>
        <button type="submit" class="btn">Submit</button>
      </form>
      <div id="myModal" class="modal">
        <!-- Modal content -->
        <div class="modal-content">
          <span class="close">&times;</span>
          <p>Some text in the Modal..</p>
        </div>
      </div>

    </div>


    <script type="text/javascript">

// multiplication table d
    var d=[
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
    [1, 2, 3, 4, 0, 6, 7, 8, 9, 5],
    [2, 3, 4, 0, 1, 7, 8, 9, 5, 6],
    [3, 4, 0, 1, 2, 8, 9, 5, 6, 7],
    [4, 0, 1, 2, 3, 9, 5, 6, 7, 8],
    [5, 9, 8, 7, 6, 0, 4, 3, 2, 1],
    [6, 5, 9, 8, 7, 1, 0, 4, 3, 2],
    [7, 6, 5, 9, 8, 2, 1, 0, 4, 3],
    [8, 7, 6, 5, 9, 3, 2, 1, 0, 4],
    [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    ];

// permutation table p
    var p=[
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
    [1, 5, 7, 6, 2, 8, 3, 0, 9, 4],
    [5, 8, 0, 3, 7, 9, 6, 1, 4, 2],
    [8, 9, 1, 6, 0, 4, 3, 5, 2, 7],
    [9, 4, 5, 3, 1, 2, 6, 8, 7, 0],
    [4, 2, 8, 6, 5, 7, 3, 9, 0, 1],
    [2, 7, 9, 3, 8, 0, 6, 4, 1, 5],
    [7, 0, 4, 6, 9, 1, 3, 2, 5, 8]
    ];

// inverse table inv
    var inv = [0, 4, 3, 2, 1, 5, 6, 7, 8, 9];

    // converts string or number to an array and inverts it
    function invArray(array){

        if (Object.prototype.toString.call(array) == "[object Number]"){
            array = String(array);
        }

        if (Object.prototype.toString.call(array) == "[object String]"){
            array = array.split("").map(Number);
        }

    	return array.reverse();

        }

      // generates checksum
      function generate(array){

      	var c = 0;
      	var invertedArray = invArray(array);

      	for (var i = 0; i < invertedArray.length; i++){
      		c = d[c][p[((i + 1) % 8)][invertedArray[i]]];
      	}

      	return inv[c];
        }

        // validates checksum
        function validate(array) {

            var c = 0;
            var invertedArray = invArray(array);

            for (var i = 0; i < invertedArray.length; i++){
            	c=d[c][p[(i % 8)][invertedArray[i]]];
            }

            if(c === 0)
            {
              document.getElementById("check_aadhar").style.display = "none";
              return true;
            }
            else{
              document.getElementById("check_aadhar").style.display = "block";
              return false;
            }
          }
          function isNumberKey(evt)
       {
          var charCode = (evt.which) ? evt.which : event.keyCode
          if (charCode != 46 && charCode > 31
            && (charCode < 48 || charCode > 57))
             return false;

          return true;
       }


      function verhoeffvalidate(){
        document.getElementById("check_aadhar").style.display = "none";
        var aadharno=document.getElementById('aadhar').value;
        var array=[]=(aadharno.split('')).map(Number);
        if(array=="" || array.length!=12)
        {
          document.getElementById("check_aadhar").style.display = "block";
          return false;
        }
        else{
        validate(array);

        }
      }

    </script>

  </body>
</html>
