<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title>index</title>
  </head>
  <body>
    <nav class="navbar navbar-default">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Home</a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
          <ul class="nav navbar-nav">
            <li><a href="#">About</a></li>
            <li><a href="#">Shooting Locations</a></li>
            <li><a href="#">Approved Films</a></li>
            <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="#">Stakeholders
              <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="#">Police Department</a></li>
                <li><a href="#">Municipal Department</a></li>
                <li><a href="#">Archaelogical Department</a></li>
              </ul>
            </li>
            <li><a href="#">DFSP Approval</a></li>
            <li><a href="#">Contact</a></li>
          </ul>
        </div>
      </div>
    </nav>
    <div class="box parent">
      <div class="container box  newold">
      <div class="container col-md-6 box new">
        <a href="newproduction.php"><button type="button" class="btn btn-primary btn-lg">New Production - Register</button></a>
      </div>
      <div class="container col-md-6 box old">
        <button type="button" class="btn btn-success btn-lg">Existing Production - Log in</button>
      </div>
     </div>
   </div>
  </body>
</html>
