<?php
$pname=$_POST['pname'];
$prname=$_POST['prname'];
$email=$_POST['email'];
$aadhar=$_POST['aadhar'];
 ?>
