<?php
$pname=$_POST['pname'];
$oname=$_POST['oname'];
$email=$_POST['email'];
$mobile=$_POST['mobile'];
$address=$_POST['address'];
$aadhar=$_POST['aadhar'];

 ?>
