<?php
$pname=$_POST['pname'];
$oname=$_POST['oname'];
$email=$_POST['email'];
$mobile=$_POST['mobile'];
$address=$_POST['address'];
$aadhar=$_POST['aadhar'];
include('..\includes\dbh.inc.php');
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql = "INSERT INTO registerforms (productionname, productionowner, email, mobile, address, aadharno)
VALUES ('$pname', '$oname', '$email', '$mobile', '$address', '$aadhar')";
if (mysqli_query($conn, $sql)) {
  header('Refresh:2; url=index.php');
  echo '<script type="text/javascript">
  window.alert("Your request sent successfully. Our officials will contact you soon.");
  </script>';
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
 ?>
